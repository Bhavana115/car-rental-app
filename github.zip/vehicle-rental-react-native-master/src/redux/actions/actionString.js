export const ACTION_STRING = {
    auth: 'AUTH',
    user: 'USER',
    logout: 'LOGOUT',
    listVehicle: 'LIST_VEHICLE',
    listCar: 'LIST_CAR',
    listMotorbike: 'LIST_MOTORBIKE',
    listBike: 'LIST_Bike'
}