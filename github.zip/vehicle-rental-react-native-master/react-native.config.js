module.exports = {
    project: {
        ios: {},
        android: {}
    },
    asserts: ['./src/fonts/']
}